package com.backend.cargaexpress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CargaexpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
