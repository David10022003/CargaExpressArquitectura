/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.controllers;

import com.backend.cargaexpress.entities.Carga;
import com.backend.cargaexpress.services.CargaService;
import com.backend.cargaexpress.services.UsuarioService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cargas")
public class CargaController {
    @Autowired
    private CargaService cargaService;

    @PostMapping("/crear")
    public ResponseEntity<Carga> crearCarga(@RequestBody Carga carga) {
        Carga temp = cargaService.crearCarga(carga);
        ResponseEntity salida = new ResponseEntity<>(temp, HttpStatus.CREATED);
        cambiarEstadoCarga(temp.getId(), "actualizar"); 
        return salida;
    }

    @GetMapping("/propietario/{propietarioCarga}")
    public ResponseEntity<List<Carga>> obtenerCargasPorPropietario(@PathVariable String propietarioCarga) {
        return new ResponseEntity<>(cargaService.obtenerCargasPorPropietario(propietarioCarga), HttpStatus.OK);
    }
    
    @GetMapping("/listaAll")
    public ResponseEntity<List<Carga>> obtenerCargas() {
        return new ResponseEntity<>(cargaService.obtenerCargas(), HttpStatus.OK);
    }
    
    @GetMapping("/conductor/{conductor}")
    public ResponseEntity<List<Carga>> obtenerCargas(@PathVariable String conductor) {
        return new ResponseEntity<>(cargaService.obtenerPorConductor(conductor), HttpStatus.OK);
    }    
    
    
    @GetMapping("/id/{idCarga}")
    public ResponseEntity<Optional<Carga>> obtenerCargaPorId(@PathVariable String idCarga) {
        return new ResponseEntity<>(cargaService.obtenerCargaPorId(idCarga), HttpStatus.OK);
    }

    @PutMapping("/{id}/estado/{email}")
    public ResponseEntity<Carga> cambiarEstadoCarga(@PathVariable String id, @PathVariable String email) {
        Carga carga = cargaService.cambiarEstado(id, email);
        if (carga != null) {
            return ResponseEntity.ok(carga);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
