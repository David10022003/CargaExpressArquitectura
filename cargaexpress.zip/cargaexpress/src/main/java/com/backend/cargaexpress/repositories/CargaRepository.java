/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.backend.cargaexpress.repositories;

import com.backend.cargaexpress.entities.Carga;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CargaRepository extends MongoRepository<Carga, String> {
    // Método para buscar cargas por propietario de carga
    List<Carga> findByPropietarioCarga(String propietarioCarga);
    List<Carga> findAll();
    List<Carga> findByConductor(String conductor);
}