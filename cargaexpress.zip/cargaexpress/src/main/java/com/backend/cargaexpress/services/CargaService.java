/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.services;

import com.backend.cargaexpress.entities.Carga;
import com.backend.cargaexpress.entities.Usuario;
import com.backend.cargaexpress.repositories.CargaRepository;
import com.backend.cargaexpress.repositories.UsuarioRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CargaService {
    @Autowired
    private CargaRepository cargaRepository;

    public Carga crearCarga(Carga carga) {
        return cargaRepository.save(carga);
    }

    public List<Carga> obtenerCargasPorPropietario(String propietarioCarga) {
        return cargaRepository.findByPropietarioCarga(propietarioCarga);
    }
    
    public List<Carga> obtenerCargas(){
        return cargaRepository.findAll();
    }

    public Optional<Carga> obtenerCargaPorId(String idCarga) {
        return cargaRepository.findById(idCarga);
    }
    
    public List<Carga> obtenerPorConductor(String conductor){
        return cargaRepository.findByConductor(conductor);
    }

    public Carga cambiarEstado(String id, String emailConductor) {
        Optional<Carga> optionalCarga = cargaRepository.findById(id);
        String[] estado = new String[] {"Creado", "Asignado", "En viaje", "Finalizado"};
        if (optionalCarga.isPresent()) {
            Carga carga = optionalCarga.get();
            int posicion = -1;
            if (carga.getEstado().equals(estado[0])) {
                posicion = 0;
                carga.setConductor(emailConductor);
            }
            else if (carga.getEstado().equals(estado[1]))
                posicion = 1;
            else if (carga.getEstado().equals(estado[2]))
                posicion = 2;
            else if (carga.getEstado().equals(estado[3]))
                posicion = 3;
            carga.setEstado(estado[posicion+1]);
            return cargaRepository.save(carga);
        } else {
            return null; 
        }
    }

    
}
