/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.backend.cargaexpress.repositories;

import com.backend.cargaexpress.entities.Camion;
import java.util.List;
import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 *
 * @author User
 */
public interface CamionRepository extends MongoRepository<Camion, String> {
    boolean existsByConductor(String idConductor);
    List<Camion> findByPropietario(String propietario);
    Optional<Camion> findByPlaca(String placa);
    boolean existsByPlacaAndConductor(String placa, String conductor);
}