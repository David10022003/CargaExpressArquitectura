/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.backend.cargaexpress.entities.AplicacionCarga;
import com.backend.cargaexpress.entities.Camion;
import com.backend.cargaexpress.repositories.AplicacionCargaRepository;
import com.backend.cargaexpress.repositories.CamionRepository;

@Service
public class AplicacionCargaService {

    @Autowired
    private AplicacionCargaRepository aplicacionCargaRepository;

    @Autowired
    private CamionRepository camionRepository;

    public AplicacionCarga aplicarCarga(String idCarga, String placaCamion) {
        Camion temp = camionRepository.findByPlaca(placaCamion).get();
        if (temp != null && !temp.getConductor().equals("")) {
                AplicacionCarga aplicacionCarga = new AplicacionCarga();
                aplicacionCarga.setIdCarga(idCarga);
                aplicacionCarga.setPlacaCamion(placaCamion);
                aplicacionCargaRepository.save(aplicacionCarga);
                return aplicacionCarga;
        } else {
            throw new RuntimeException("El conductor no está registrado o ya está asignado a otro camión");
        }
    }

    public List<Camion> verCamionesAplicaciones (String idCarga) {
        List<AplicacionCarga> aplicaciones = aplicacionCargaRepository.findByIdCarga(idCarga);
        List<Camion> camiones = new ArrayList<>();
        for (AplicacionCarga aplicacion : aplicaciones) {
            Optional<Camion> optionalCamion = camionRepository.findByPlaca(aplicacion.getPlacaCamion());
            if (optionalCamion.isPresent()) {
                Camion camion = optionalCamion.get();
                camiones.add(camion);
            } else {
                throw new RuntimeException("Camión no encontrado");
            }
        }
        return camiones;
    }
}
