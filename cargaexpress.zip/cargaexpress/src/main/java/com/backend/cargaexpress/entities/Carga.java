/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "cargas")
public class Carga {
    @Id
    private String id;
    private String fecha;
    private String propietarioCarga;
    private String origen;
    private String destino;
    private String dimensiones;
    private double peso;
    private double valorAsegurado;
    private String empaque;
    private String estado;
    private String conductor;

    public Carga() {
    }

    public Carga(String id, String fecha, String propietarioCarga, String origen, String destino, String dimensiones, double peso, double valorAsegurado, String empaque, String estado, String conductor) {
        this.id = id;
        this.fecha = fecha;
        this.propietarioCarga = propietarioCarga;
        this.origen = origen;
        this.destino = destino;
        this.dimensiones = dimensiones;
        this.peso = peso;
        this.valorAsegurado = valorAsegurado;
        this.empaque = empaque;
        this.estado = estado;
        this.conductor = conductor;
    }

    public String getId() {
        return id;
    }

    public String getConductor() {
        return conductor;
    }

    public void setConductor(String conductor) {
        this.conductor = conductor;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getPropietarioCarga() {
        return propietarioCarga;
    }

    public void setPropietarioCarga(String propietarioCarga) {
        this.propietarioCarga = propietarioCarga;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(String dimensiones) {
        this.dimensiones = dimensiones;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getValorAsegurado() {
        return valorAsegurado;
    }

    public void setValorAsegurado(double valorAsegurado) {
        this.valorAsegurado = valorAsegurado;
    }

    public String getEmpaque() {
        return empaque;
    }

    public void setEmpaque(String empaque) {
        this.empaque = empaque;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}