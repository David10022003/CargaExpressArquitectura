/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.services;

import com.backend.cargaexpress.entities.Camion;
import com.backend.cargaexpress.repositories.CamionRepository;
import com.backend.cargaexpress.repositories.UsuarioRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CamionService {
    @Autowired
    private CamionRepository camionRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Camion crearCamion(Camion camion) {
        return camionRepository.save(camion);
    }

    public Camion asignarConductor(String placa, String emailConductor) {
        if (verificarConductor(emailConductor)) {
            Optional<Camion> optionalCamion = camionRepository.findById(placa);
            if (optionalCamion.isPresent()) {
                Camion camion = optionalCamion.get();
                camion.setConductor(emailConductor);
                return camionRepository.save(camion);
            } else {
                throw new RuntimeException("Camión no encontrado");
            }
        } else {
            throw new RuntimeException("El conductor no está registrado o ya está asignado a otro camión");
        }
    }

    public boolean verificarConductor(String emailConductor) {
        return usuarioRepository.existsByCorreo(emailConductor) && !camionRepository.existsByConductor(emailConductor) && usuarioRepository.existsByCorreoAndRol(emailConductor, "conductor");
    }

    public List<Camion> obtenerCamionesByPropietario(String propietario) {
        return camionRepository.findByPropietario(propietario);
    }

    public Optional<Camion> obtenerCamionByPlaca(String placa) {
        return camionRepository.findByPlaca(placa);
    }
}