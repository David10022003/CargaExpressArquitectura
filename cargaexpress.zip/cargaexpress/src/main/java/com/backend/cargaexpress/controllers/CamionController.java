/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.controllers;

import com.backend.cargaexpress.entities.Camion;
import com.backend.cargaexpress.services.CamionService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping("/api/camiones")
public class CamionController {
    @Autowired
    private CamionService camionService;

    @PostMapping("/crear")
    public Camion crearCamion(@RequestBody Camion camion) {
        return camionService.crearCamion(camion);
    }

    @PostMapping("/asignar/{placa}/{emailConductor}")
    public Camion asignarConductor(@PathVariable String placa, @PathVariable String emailConductor) {
        return camionService.asignarConductor(placa, emailConductor);
    }

    @GetMapping("/propietario/{propietario}")
    public List<Camion> obtenerCamionesByPropietario(@PathVariable String propietario) {
        return camionService.obtenerCamionesByPropietario(propietario);
    }

    @GetMapping("/placa/{placa}")
    public Optional<Camion> obtenerCamionByPlaca(@PathVariable String placa) {
        return camionService.obtenerCamionByPlaca(placa);
    }
}