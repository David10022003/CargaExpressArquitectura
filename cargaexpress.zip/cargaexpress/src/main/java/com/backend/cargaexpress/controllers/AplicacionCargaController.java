/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.backend.cargaexpress.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.backend.cargaexpress.entities.AplicacionCarga;
import com.backend.cargaexpress.entities.Camion;
import com.backend.cargaexpress.services.AplicacionCargaService;

@RestController
@RequestMapping("/api/aplicar-carga")
public class AplicacionCargaController {

    @Autowired
    private AplicacionCargaService aplicacionCargaService;

    @PutMapping("/{id}")
    public ResponseEntity<AplicacionCarga> aplicarCarga(@RequestParam("placaCamion") String placaCamion, @PathVariable String id) {
        AplicacionCarga aplicacion = aplicacionCargaService.aplicarCarga(id, placaCamion);
        return new ResponseEntity<>(aplicacion, HttpStatus.CREATED);
    }

    @GetMapping("/verAplicaciones/{id}")
    public ResponseEntity<List<Camion>> verCamionesAplicaciones (@PathVariable String id) {
        List<Camion> camiones = aplicacionCargaService.verCamionesAplicaciones(id);
        return new ResponseEntity<>(camiones, HttpStatus.CREATED);
    }
}
